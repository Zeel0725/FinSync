# Design Guidelines: Simple Login Page with Google OAuth

## Design Approach
**Selected Approach**: Design System (Clean & Functional)
**Justification**: Login pages require trust, clarity, and ease of use. A utility-focused approach ensures optimal user experience and conversion rates.
**Design System**: Material Design principles with modern minimalist aesthetics
**Key Principles**: Simplicity, trust-building, accessibility, mobile-first responsive design

## Core Design Elements

### A. Color Palette
**Light Mode:**
- Primary: 59 91% 50% (Modern blue for trust and reliability)
- Background: 0 0% 98% (Clean white background)
- Surface: 0 0% 100% (Pure white for cards/forms)
- Text Primary: 222 84% 5% (Near-black for readability)
- Text Secondary: 215 14% 34% (Muted gray for labels)
- Border: 214 32% 91% (Subtle gray borders)

**Dark Mode:**
- Primary: 59 91% 60% (Slightly lighter blue for contrast)
- Background: 222 84% 5% (Deep dark background)
- Surface: 217 33% 8% (Elevated dark surface)
- Text Primary: 210 40% 98% (Near-white text)
- Text Secondary: 215 20% 65% (Muted light gray)
- Border: 217 33% 17% (Dark borders)

### B. Typography
- **Primary Font**: Inter (Google Fonts) - Modern, highly legible
- **Heading**: 32px weight-600 for main "Sign In" title
- **Body**: 16px weight-400 for form labels and helper text
- **Button Text**: 16px weight-500 for call-to-action buttons
- **Small Text**: 14px weight-400 for links and secondary information

### C. Layout System
**Spacing Units**: Tailwind units of 4, 6, and 8 (p-4, m-6, h-8, etc.)
- Consistent 24px (6 units) spacing between major elements
- 16px (4 units) for tight spacing within components
- 32px (8 units) for generous section separation

### D. Component Library

**Core Components:**
1. **Login Card**: Centered, elevated card (max-width 400px) with subtle shadow and rounded corners
2. **Input Fields**: Clean, modern text inputs with floating labels and focus states
3. **Google OAuth Button**: Prominent button with Google branding and icon
4. **Primary CTA Button**: Solid background for main actions
5. **Link Components**: Subtle underlined links for "Forgot Password" etc.

**Navigation**: None required (single-page focus)
**Forms**: Email/password fields with proper validation states
**Data Displays**: Success/error message components
**Overlays**: Not needed for this simple implementation

### E. Layout Structure

**Single-Page Centered Layout:**
- Viewport-centered login card
- Clean background with subtle gradient or solid color
- Generous whitespace around the login form
- Mobile-responsive with proper touch targets

**Form Layout:**
1. Logo/Brand element (if applicable)
2. "Sign In" heading
3. Email input field
4. Password input field
5. "Sign In" primary button
6. Divider with "OR"
7. "Sign in with Google" button
8. "Forgot password?" link
9. "Don't have an account? Sign up" link

### F. Interaction Patterns
- **Smooth Focus States**: Clear visual feedback for form inputs
- **Loading States**: Subtle loading indicators during authentication
- **Error Handling**: Inline validation with clear, helpful messages
- **Success Flow**: Smooth transition to dashboard/protected area

### G. Accessibility Features
- High contrast ratios (4.5:1 minimum)
- Proper focus management and keyboard navigation
- Screen reader compatible labels and ARIA attributes
- Touch-friendly button sizes (minimum 44px)
- Consistent dark mode implementation across all inputs

## Images
No hero image required. This is a utility-focused login page that should maintain clean, distraction-free design. If branding is needed, include only:
- Small company logo above the login form (max 120px width)
- Subtle background pattern or gradient (optional, very minimal)

The design prioritizes conversion and usability over visual storytelling.