import GoogleLoginButton from '../GoogleLoginButton';

export default function GoogleLoginButtonExample() {
  return (
    <div className="space-y-4 p-6">
      <GoogleLoginButton />
      <GoogleLoginButton variant="default" />
      <GoogleLoginButton size="lg" />
    </div>
  );
}