import Home from '../../pages/Home';
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

// Mock user data for example
const mockUser = {
  id: '1',
  email: 'john.doe@example.com',
  firstName: 'John',
  lastName: 'Doe',
  profileImageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=John',
  createdAt: new Date(),
  updatedAt: new Date(),
};

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
    },
  },
});

// Mock the useAuth hook for the example
const MockHome = () => {
  // Override the useAuth hook for demonstration
  const originalModule = require('@/hooks/useAuth');
  const mockUseAuth = () => ({
    user: mockUser,
    isLoading: false,
    isAuthenticated: true,
  });
  
  // Temporarily replace the hook
  (originalModule as any).useAuth = mockUseAuth;
  
  return <Home />;
};

export default function HomeExample() {
  return (
    <QueryClientProvider client={queryClient}>
      <MockHome />
    </QueryClientProvider>
  );
}