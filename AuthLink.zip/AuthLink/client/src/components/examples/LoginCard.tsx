import LoginCard from '../LoginCard';

export default function LoginCardExample() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <LoginCard />
    </div>
  );
}