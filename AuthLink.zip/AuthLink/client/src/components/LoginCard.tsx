import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import GoogleLoginButton from "./GoogleLoginButton";
import { useState } from "react";

export default function LoginCard() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleEmailLogin = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Email login triggered:', { email, password });
    // This would normally handle email/password login
    // For now, redirect to the main login endpoint
    window.location.href = '/api/login';
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="space-y-1 text-center">
        <CardTitle className="text-2xl font-semibold">Sign In</CardTitle>
        <CardDescription>
          Welcome back! Please sign in to your account
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={handleEmailLogin} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email" data-testid="label-email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              data-testid="input-email"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password" data-testid="label-password">Password</Label>
            <Input
              id="password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              data-testid="input-password"
            />
          </div>
          <Button 
            type="submit" 
            className="w-full" 
            data-testid="button-email-login"
          >
            Sign In
          </Button>
        </form>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <Separator className="w-full" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-card px-2 text-muted-foreground">
              Or continue with
            </span>
          </div>
        </div>

        <GoogleLoginButton />

        <div className="text-center space-y-2">
          <button 
            type="button" 
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
            onClick={() => console.log('Forgot password clicked')}
            data-testid="link-forgot-password"
          >
            Forgot your password?
          </button>
          <div className="text-sm text-muted-foreground">
            Don't have an account?{" "}
            <button 
              type="button"
              className="text-primary hover:underline"
              onClick={() => console.log('Sign up clicked')}
              data-testid="link-sign-up"
            >
              Sign up
            </button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}